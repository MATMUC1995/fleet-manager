<?php
namespace App\DataPersister;

use ApiPlatform\State\PersisterInterface;
use ApiPlatform\Metadata\Operation;
use App\Entity\Fleet;
use App\Repository\VehicleRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class FleetDataPersister implements PersisterInterface
{
    public function __construct(
        private EntityManagerInterface $entityManager,
        private VehicleRepository $vehicleRepository,
        private RequestStack $requestStack
    ) {}

    public function supports(object $data, Operation $operation = null, array $context = []): bool
    {
        return $data instanceof Fleet;
    }

    public function persist(object $data, Operation $operation = null, array $context = []): object
    {
        /** @var Fleet $data */
        $vehicles      = $data->getVehicles();
        $newCollection = new \Doctrine\Common\Collections\ArrayCollection();

        foreach ($vehicles as $vehicle) {
            $reg    = $vehicle->getRegistrationNumber();
            $driver = $vehicle->getDriverName();

            if (!$reg || !$driver) {
                throw new BadRequestHttpException('Pojazd musi mieć numer rejestracyjny i nazwisko kierowcy.');
            }

            $existing = $this->vehicleRepository
                             ->findOneByRegistrationAndDriver($reg, $driver);

            if ($existing) {
                $newCollection->add($existing);
            } else {
                $newCollection->add($vehicle);
                // dzięki cascade={"persist"} w encji Fleet nowy Vehicle zostanie zapisany
            }
        }

        $data->getVehicles()->clear();
        foreach ($newCollection as $v) {
            $data->addVehicle($v);
        }

        $this->entityManager->persist($data);
        $this->entityManager->flush();
        return $data;
    }

    public function remove(object $data, Operation $operation = null, array $context = []): void
    {
        $this->entityManager->remove($data);
        $this->entityManager->flush();
    }
}
