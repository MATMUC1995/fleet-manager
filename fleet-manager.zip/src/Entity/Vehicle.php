<?php
namespace App\Entity;

use ApiPlatform\Metadata\ApiResource;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Serializer\Annotation\Groups;
use App\Repository\VehicleRepository;

#[ORM\Entity(repositoryClass: VehicleRepository::class)]
#[ORM\Table(name: 'vehicle')]
#[ApiResource(
    normalizationContext: ['groups' => ['vehicle:read']],
    denormalizationContext: ['groups' => ['vehicle:write']],
)]
class Vehicle
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    #[Groups(['vehicle:read', 'fleet:read'])]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 50)]
    #[Assert\NotBlank(message: 'Numer rejestracyjny jest wymagany')]
    #[Groups(['vehicle:read', 'vehicle:write', 'fleet:read', 'fleet:write'])]
    private ?string $registrationNumber = null;

    #[ORM\Column(type: 'string', length: 100)]
    #[Assert\NotBlank(message: 'Imię i nazwisko kierowcy jest wymagane')]
    #[Groups(['vehicle:read', 'vehicle:write', 'fleet:read', 'fleet:write'])]
    private ?string $driverName = null;

    #[ORM\ManyToMany(targetEntity: Fleet::class, mappedBy: 'vehicles')]
    #[Groups(['vehicle:read'])]
    private Collection $fleets;

    public function __construct()
    {
        $this->fleets = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getRegistrationNumber(): ?string
    {
        return $this->registrationNumber;
    }

    public function setRegistrationNumber(string $registrationNumber): self
    {
        $this->registrationNumber = $registrationNumber;
        return $this;
    }

    public function getDriverName(): ?string
    {
        return $this->driverName;
    }

    public function setDriverName(string $driverName): self
    {
        $this->driverName = $driverName;
        return $this;
    }

    /**
     * @return Collection<int, Fleet>
     */
    public function getFleets(): Collection
    {
        return $this->fleets;
    }

    public function addFleet(Fleet $fleet): self
    {
        if (!$this->fleets->contains($fleet)) {
            $this->fleets->add($fleet);
            $fleet->addVehicle($this);
        }
        return $this;
    }

    public function removeFleet(Fleet $fleet): self
    {
        if ($this->fleets->removeElement($fleet)) {
            $fleet->removeVehicle($this);
        }
        return $this;
    }
}
