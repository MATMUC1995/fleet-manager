<?php
namespace App\Controller;

use App\Entity\Vehicle;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class VehicleController extends AbstractController
{
    #[Route('/vehicle', name: 'vehicle_list')]
    public function list(EntityManagerInterface $em)
    {
        $vehicles = $em->getRepository(Vehicle::class)->findAll();
        return $this->render('vehicle/list.html.twig', [
            'vehicles' => $vehicles,
        ]);
    }
}
