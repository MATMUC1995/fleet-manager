<?php
namespace App\Controller;

use App\Entity\Fleet;
use App\Form\FleetType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class FleetController extends AbstractController
{
    #[Route('/fleet/new', name: 'fleet_new')]
    public function new(Request $request, EntityManagerInterface $em)
    {
        $fleet = new Fleet();
        $form = $this->createForm(FleetType::class, $fleet);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            // Manualnie wykorzystamy zasady z DataPersistera (lub przeniesiemy logikę do serwisu),
            // ale na potrzeby tego formularza: 
            // Po walidacji Symfony, wywołujemy standardowe API (lub zapisujemy ręcznie).
            $em->persist($fleet);
            $em->flush();

            $this->addFlash('success', 'Flota została utworzona.');
            return $this->redirectToRoute('fleet_list');
        }

        return $this->render('fleet/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('/fleet/{id}/edit', name: 'fleet_edit')]
    public function edit(Fleet $fleet, Request $request, EntityManagerInterface $em)
    {
        $form = $this->createForm(FleetType::class, $fleet);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();
            $this->addFlash('success', 'Flota została zaktualizowana.');
            return $this->redirectToRoute('fleet_list');
        }

        return $this->render('fleet/edit.html.twig', [
            'form' => $form->createView(),
            'fleet' => $fleet,
        ]);
    }

    #[Route('/fleet', name: 'fleet_list')]
    public function list(EntityManagerInterface $em)
    {
        $fleets = $em->getRepository(Fleet::class)->findAll();
        return $this->render('fleet/list.html.twig', [
            'fleets' => $fleets,
        ]);
    }
}
