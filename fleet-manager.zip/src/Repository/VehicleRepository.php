<?php
namespace App\Repository;

use App\Entity\Vehicle;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class VehicleRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Vehicle::class);
    }

    public function findOneByRegistrationAndDriver(string $registration, string $driverName): ?Vehicle
    {
        return $this->createQueryBuilder('v')
            ->andWhere('v.registrationNumber = :reg')
            ->andWhere('v.driverName = :driver')
            ->setParameter('reg', $registration)
            ->setParameter('driver', $driverName)
            ->getQuery()
            ->getOneOrNullResult();
    }
}
